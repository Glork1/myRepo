''' 

Goal: predict which passengers died or not
0: No
1: Yes 

'''

import pandas as pd
df = pd.read_csv("C:\\Users\\I685383\\Desktop\\S\\Python tests\\KaggleTitanic\\train.csv",na_values='NaN')
df_test = pd.read_csv("C:\\Users\\I685383\\Desktop\\S\\Python tests\\KaggleTitanic\\test.csv",na_values='NaN')


# Name of the columns
pd.set_option('display.max_columns', None) # to inspect all the columns
pd.set_option('display.float_format', lambda x: '%.2f' % x) # to suppress scientific notation
print(df.columns) # list all the columns (in a dataframe) 
list_columns = df.columns.tolist()

# Summary statistics
print(df.describe()) # generate a summary for each column. 25% etc return the 25% percentile. df.describe('percentiles=None' to remove it)
df.hist(figsize=(15,15))

# Pairwise scatter plot to get side-by-side boxplots
from pandas.plotting import scatter_matrix
scatter_matrix(df, alpha = 0.2, figsize = (10, 10), diagonal = 'hist')

# Correlation matrix
import numpy as np
correlation_matrix = np.corrcoef((df[['PassengerId','Survived','Pclass','Age','SibSp','Parch','Fare']]).T)

Y = df.iloc[:,1]
X = df.drop('Survived',axis=1)
X_test = df_test
# List all possible titles Mr, Mrs, Master etc
name = df.Name
name_test = df_test.Name
liste_title = []
for title in name:
    extract = (title.split(",",1)[1]).split(".",1)[0]
    if extract not in liste_title:
        liste_title.append(extract)

# Let's create - actually replace the Name variable - another dummy feature based on this feature
# +1 if title not Mr or Mrs and 0 otherwise

increaseChance = []
for title in name:
    common = [' Mr',' Mrs', ' Miss'] # completer Mrs etc
    if (common[0] not in title) and ((common[1] not in title)) and (common[2] not in title):
        increaseChance.append(1)
    else:
        increaseChance.append(0)

increaseChance = pd.Series(increaseChance)
increaseChance_test = []
for title in name_test:
    common = [' Mr',' Mrs', ' Miss'] # completer Mrs etc
    if (common[0] not in title) and ((common[1] not in title)) and (common[2] not in title):
        increaseChance_test.append(1)
    else:
        increaseChance_test.append(0)

increaseChance = pd.Series(increaseChance)
increaseChance_test = pd.Series(increaseChance_test)
X = X.drop('Name',axis=1)
X_test = X_test.drop('Name',axis=1)

X = pd.concat([X,increaseChance],axis=1)
X_test = pd.concat([X_test,increaseChance_test],axis=1)

# We also get rid of Ticket variable, maybe to considered later...
X = X.drop('Ticket',axis=1) 
X_test = X_test.drop('Ticket',axis=1) 

# We dummify some variables
dummies = pd.get_dummies(df[['Sex', 'Embarked']])
dummies_test = pd.get_dummies(df_test[['Sex', 'Embarked']])

# We will have to treat Cabin as well later
X = X.drop(['Sex','Embarked','Cabin'],axis = 1)
X_test = X_test.drop(['Sex','Embarked','Cabin'],axis = 1)
X = pd.concat([X, dummies[['Sex_female', 'Sex_male','Embarked_C','Embarked_Q','Embarked_S']]], axis=1) # concatenate
X_test = pd.concat([X_test, dummies_test[['Sex_female', 'Sex_male','Embarked_C','Embarked_Q','Embarked_S']]], axis=1) # concatenate

# We drop all the passengers with unknown age
#to_drop = ['nan']
#X = X[~X['Age'].isin(to_drop)] # "~" operator is for inverting , "isin" as "is in"
#Y = Y[~Y.isin(to_drop)]   
#correlation_matrix_X = np.corrcoef((X).T)

# For the time being, we drop the age 
X = X.drop('Age',axis = 1)
X_test = X_test.drop('Age',axis = 1)


''' Logistic regression '''
# Logistic regression
# Aim: fit a logistic regression model in order to predit Direction using Lag1..Lag5 and Volume

import statsmodels.api as sm

X = sm.add_constant(X) # add a column of 1 to get the intercept
X_test = sm.add_constant(X_test)
logit = sm.Logit(Y, X)
logit_result = logit.fit()
print(logit_result.summary())

prob = logit_result.predict(X_test) #X
prob= prob.values
Ypred = [0]*891 # creates a list of 1250 "Down" elements
Y_test = [0]*418
Ypred = np.where(prob>0.5,1,0) # actually all above is useless since one can use the pred_table function
Y_test = np.where(prob>0.5,1,0)

print(logit_result.pred_table())

'''

[[471.  78.]
 [ 94. 248.]]

(en utilisant le fichier train.csv et logit = sm.Logit(Ytrain, X))
TRAINING Error: 80% 

'''

